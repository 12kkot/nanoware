#pragma once

struct view_matrix
{
    float m[16];
};

struct vector2
{
    float x, y;
};

struct vector3
{
    float x, y, z;
};

struct vector4
{
    float x, y, z, w;
};